Page({
    mixins: [require('../../mixin/themeChanged')],
});